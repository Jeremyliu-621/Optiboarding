# ONBOARD_06 — Guided Tour Foundation: Engine, Spotlight, Overlay System

## Purpose
Build the underlying engine for the post-onboarding guided tour. This is inspired by Image 4 (Stripe's post-onboarding dashboard state) — the product is fully visible and usable behind the guidance UI, and contextual overlays draw attention to specific areas.

## What the Tour Does (High Level)
The tour is a sequential walkthrough of the dashboard:
1. Start on the Dashboard home page — points to the "Getting Started" checklist and the feature cards
2. Navigate to Optibot page in the sidebar — shows an explanation overlay
3. Navigate to Repo Insights — shows an explanation overlay
4. Navigate to Configuration → Settings — shows an explanation overlay
5. Navigate to Configuration → Guidelines — shows an explanation overlay
6. Navigate to Codebase Map — shows an explanation overlay
7. Tour complete — dismiss UI

Each step has:
- A sidebar highlight (the relevant nav item glows/is highlighted)
- An explanation overlay panel (the Image 5 / Image 4 style gradient panel)
- Navigation controls (Next, Back, Skip tour)

## Architecture

### TourProvider
Create `src/components/onboarding/TourProvider.tsx` — a client component that:
- Reads tour state from localStorage (`tourCurrentStep`, `tourCompleted`)
- Manages the current tour step
- Provides tour state via React context: `useTour()` hook
- Handles navigation between steps (including programmatic Next.js router navigation)
- Renders the tour overlay components

### TourContext
```typescript
interface TourContextValue {
  isActive: boolean
  currentStep: number
  totalSteps: number
  goNext: () => void
  goBack: () => void
  skipTour: () => void
  completeTour: () => void
}
```

Mount `<TourProvider>` inside `OnboardingProvider`, wrapping the dashboard content.

### Sidebar Highlight System
The sidebar needs to participate in the tour. The sidebar items need to know when they're the "active tour step target."

In the sidebar component (`layout.tsx` or wherever the nav is rendered), consume `useTour()`. For each nav item, check if the current tour step targets that item. If yes, apply a highlight class:
- The nav item gets a subtle highlight: a pulsing ring or a bright left border (4px, brand primary, animated pulse at 1.5s interval)
- The sidebar item background shifts to `--bg-elevated` and stays there (not just on hover)
- The text colour shifts to `--text-primary` (brighter)

This should feel like Stripe's blue highlighted sidebar items in Image 4 — clear, attention-grabbing, but not aggressive.

### Programmatic Navigation
When the tour advances to a step that requires a different page, use `router.push()` to navigate. The tour step definition includes a `route: string` field. After navigation, wait for the page to be mounted before showing the overlay (use a short delay, 400ms, or a route change listener if available).

## The Explanation Overlay Panel

This is the core visual of the tour. Inspired by:
- Image 4: Stripe's floating panel, bottom-right, gradient background, content inside it
- Image 5: The clean toggle-row settings panel

### Panel Anatomy
The panel is a floating card that appears in a consistent position for each tour step. It is NOT a tooltip that points at an element — it's a standalone panel that sits in a fixed position on the screen (bottom-right, similar to Stripe's approach in Image 4).

Panel dimensions: approximately 360px wide, height adapts to content, max 480px.
Position: `fixed`, `bottom: 32px`, `right: 32px`. Always visible regardless of scroll.

Panel visual treatment:
- Background: a subtle gradient. NOT a plain solid colour. Use a radial gradient that bleeds from a muted brand-purple tint in the top-left corner to a slightly darker base. Something like: `background: radial-gradient(ellipse at top left, hsl(275, 20%, 18%) 0%, hsl(275, 15%, 11%) 70%)`. This should feel premium, like a dark glass card.
- Border: a single 1px border in `hsl(275, 20%, 25%)` — subtle, just enough definition
- Border-radius: `12px`
- Box shadow: `0 8px 32px rgba(0,0,0,0.5)` — this floats the card
- Padding: `24px`

Panel content (per step):
- A small step counter: `Step 2 of 6` in muted uppercase tracking, very small font
- A panel title: bold, `--text-primary` colour, 18px
- A description paragraph: 14px, `--text-secondary`, line-height 1.6
- Optional: a small UI preview snippet (for pages that have distinct UI — like Optibot or Settings)
- A footer row: "← Back" muted link left, "Next →" filled button right (small), "Skip tour" far right in muted text

### Panel Animation
- Entrance: slide up from `bottom: 16px` to `bottom: 32px`, opacity 0 → 1, 300ms ease-out
- Exit: opposite direction, 200ms
- When content changes between steps (panel stays in same position): crossfade the content, 200ms

### Tour Progress Bar
A thin horizontal progress bar at the very top of the panel, spanning its full width. Fills from left to right as steps advance. Same style as the modal progress bar but positioned at top of the card. Height: 2px. Colour: brand primary. Background track: `hsl(275, 10%, 22%)`.

## Skip Tour
A small "Skip tour" text in the panel footer. Clicking it:
- Marks `tourCompleted: true` in localStorage
- Removes the tour overlay
- Removes the sidebar highlights
- The dashboard returns to normal

## Self-Evaluation Before Moving On
- [ ] Does `useTour()` hook correctly expose tour state?
- [ ] Does the sidebar highlight correctly apply to the target nav item per step?
- [ ] Does the highlight pulse animation render without being distracting?
- [ ] Does the tour panel render in the correct fixed position?
- [ ] Does the panel gradient look premium (not flat)?
- [ ] Does programmatic navigation work when a step requires a route change?
- [ ] Does skip tour correctly clear all tour UI?

---
*Proceed to ONBOARD_07_tour_steps.md*
