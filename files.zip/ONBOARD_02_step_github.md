# ONBOARD_02 — Step 1: Connect GitHub + Optional Integrations

## Purpose
Build the content for onboarding Step 1. The user has just authenticated with GitHub OAuth, so GitHub may already be connected — handle both states.

## What This Step Does
This step asks the user to confirm their GitHub connection and optionally connect other services (GitLab, Slack, Jira) before they start using Optibot. It's the first thing they see after logging in.

## Visual Design
Look at Stripe's Step 1 (Image 1) for layout inspiration: generous padding, a welcome headline at the top, then form-like content below. The heading uses a coloured first word ("Welcome to Stripe." — the "Welcome to Stripe." part is in brand primary colour, the rest in dark). Use the same pattern: **"Welcome to Optimal AI."** in brand purple, then a natural-language subtitle.

Content below the welcome message:

### GitHub Connection (Primary, Required)
Render a connection card — a rounded rectangle with a light grey background (`#f5f5f5`), about 60px tall, full content-width. Inside:
- Left: GitHub mark icon (Lucide `Github`) + text "GitHub" in medium weight + a sub-label showing the user's GitHub username from the session (e.g. `@jeremyliu`)
- Right: If already connected (which it will be, since they just OAuth'd): a green "Connected" chip — small, pill-shaped, `#e8f5e9` background, `#2e7d32` text, with a small checkmark. If somehow not connected: a "Connect" button.

This card is not interactive — it's a confirmation state. The user just proved they have GitHub by logging in. The card should feel like a verified receipt.

### Optional Integrations (Secondary)
Below a subtle section label ("Connect more tools — optional"), show three connection cards in a vertical list:
- GitLab
- Slack  
- Jira

Each card:
- Same rounded rectangle style as the GitHub card but slightly less prominent (maybe `#fafafa` bg)
- Left: appropriate Lucide icon + service name
- Right: a "Connect" button — outlined style (not filled), small, uses brand primary colour for border and text
- When "Connect" is clicked: the button changes to a loading spinner for 1.5s, then to a green "Connected" chip (simulated — no real OAuth)
- Once connected, the card's right side shows the same Connected chip as GitHub

### Headline Copy
```
Welcome to Optimal AI.
Let's connect your tools so Optibot has everything it needs to review your code.
```
The "Welcome to Optimal AI." portion: bold, `#5b3dc8` (or whatever the brand primary CSS var resolves to). The second sentence: normal weight, dark body colour.

## State Management
Track which optional integrations have been connected in local component state. This state will be passed up to the parent and persisted in Step 5 (the integration task). For now, just manage it in the step component and expose it via a callback prop.

## Layout Within the Modal Content Area
```
[Welcome headline — 2 lines]
[24px gap]
[GitHub card — full width]
[20px gap]
[Section label "Connect more tools — optional" in muted caps]
[12px gap]
[GitLab card]
[8px gap]
[Slack card]
[8px gap]
[Jira card]
```

All content left-aligned. No centring. Match Stripe's left-alignment pattern from Image 1.

## Edge Cases
- If the session doesn't have a GitHub username for some reason, show a generic "GitHub" label without the @handle
- The "Continue" CTA in the footer should always be enabled — GitHub is already connected, optional integrations are optional
- Connected state for optional integrations persists if the user navigates Back from Step 2 and returns to Step 1

## Self-Evaluation Before Moving On
- [ ] Does the welcome headline colour match brand primary?
- [ ] Does the GitHub card correctly show the user's @handle?
- [ ] Does the GitHub Connected chip appear immediately (not after a click)?
- [ ] Do the optional integration Connect buttons animate to Connected on click?
- [ ] Is the layout left-aligned and matching the Stripe reference style?
- [ ] Does the step look substantial and trustworthy — not thin or placeholder-y?

---
*Proceed to ONBOARD_03_step_settings.md*
