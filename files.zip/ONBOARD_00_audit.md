# ONBOARD_00 — Repo Audit & Discovery

## Purpose
Before writing a single line of code, fully understand what already exists. This task is read-only. You are mapping the terrain.

## What to Find

### 1. Existing Onboarding Code
Search for any existing onboarding modal, getting-started flow, or first-login detection. Look for:
- Any component with "onboard", "welcome", "getting-started", or "checklist" in the name
- The "Getting Started 0/3" checklist visible in Image 7 — find where this is implemented
- Any localStorage reads/writes related to onboarding state
- Any `useEffect` that checks if it's the user's first visit

Read every relevant file completely. Understand the current flow end-to-end before planning the replacement.

### 2. Auth Flow
- Find `src/app/api/auth/[...nextauth]/route.ts` and read it
- Understand what session data is available after GitHub OAuth: username, avatar, email, connected repos
- Find where the session is consumed in dashboard components — specifically how `session.user` is accessed
- Understand if there's a `callbacks.signIn` or `callbacks.jwt` hook that could signal first login

### 3. Dashboard Home Page
- Read `src/app/dashboard/page.tsx` completely
- Find where the "Getting Started" checklist currently lives
- Understand the component hierarchy: what wraps the page, what's in the layout

### 4. Dashboard Layout
- Read `src/app/dashboard/layout.tsx` completely
- Understand the sidebar navigation structure — you'll need to programmatically highlight sidebar items during the tour
- Note how navigation works (Next.js `<Link>`, `useRouter`, or `usePathname`)

### 5. Existing Component Patterns
- Find any existing modal components in `src/components/`
- Find the existing toggle switch component (referenced in Image 5 — it exists somewhere since the settings page uses them)
- Find how the design system's CSS variables are applied — check `globals.css`
- Note what animation library is available (Framer Motion is confirmed in the stack)

### 6. Dependencies
- Read `package.json` — note what's available: Framer Motion version, whether Radix UI or Headless UI exists, what icon library (Lucide React confirmed)
- Note if there's a toast/notification system already

## Output of This Task
Write a brief internal summary (as a comment block at the top of a scratch file, or just keep it in your working memory) covering:
- Where the existing onboarding lives and what to keep vs replace
- What session fields are available
- Whether a modal component exists to extend or if you're building from scratch
- What animation primitives are available
- Any gotchas or constraints discovered

Do not write any component code in this task. Just read, understand, and plan.

---
*Proceed to ONBOARD_01_modal_foundation.md*
