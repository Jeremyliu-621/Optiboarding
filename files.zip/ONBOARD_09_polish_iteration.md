# ONBOARD_09 — Polish & Iteration Pass

## Purpose
This is a dedicated quality pass. Every component built in ONBOARD_01 through ONBOARD_08 gets reviewed and iterated on. Do not treat this as a light check — treat it as the difference between "it works" and "it's good."

The standard: would a senior product designer at a company like Stripe, Linear, or Vercel approve this? If the answer is "maybe" or "probably not", fix it before moving on.

---

## Pass 1: Onboarding Modal

### Visual Fidelity to Stripe Reference
Open Images 1, 2, and 3 mentally and compare against your implementation.

- **Whitespace**: Stripe uses extremely generous padding. If the content area feels at all crowded, increase padding. The content should breathe. There's no reason to pack content in — these modals have fixed height and limited content.
- **Progress bar**: In Stripe, the progress bar is top-right, minimal, and elegant. Check: is yours positioned correctly? Does it animate smoothly on step advance? Is it the right proportions (thin, not chunky)?
- **Bottom bar**: The separator line + footer pattern. Is the separator line actually visible but subtle? Are "Back" and "Skip for now" truly text links (no button appearance) rather than buttons?
- **Modal sizing**: Is the modal large enough? Stripe's modals feel substantial — large rectangles that command attention. If yours feels small or cramped, increase the width/min-height.
- **Shadow**: The modal needs to float convincingly above the dimmed dashboard. Is the box-shadow substantial enough? Try `0 24px 64px rgba(0,0,0,0.4)`.

### Step 1 Specifics
- GitHub "Connected" chip: is the green chip readable? Does it use correct accessible contrast?
- Optional integration cards: when simulating a connection, does the button → spinner → Connected chip transition feel smooth and complete? Test the timing.
- Is the welcome headline colour correct — specifically the brand purple on the first sentence?

### Step 2 Specifics
- Toggle appearance on white background: are the inactive toggles clearly grey (not dark-mode grey that's invisible on white)?
- Section headers ("TRIGGER BEHAVIOUR", "REVIEW STYLE"): uppercase, small, muted. Check font size (should be around 11px), letter-spacing (should be 0.08em or more), and colour (should be clearly muted, not primary text).
- Row separators: 1px lines. Are they visible but subtle? Not too heavy.
- Default toggle states: auto review = ON, code suggestions = ON, all others OFF. Verify this on component mount.

### Step 3 Specifics
- Two-column layout: does the left column dominate correctly (~55%)? Does the right column's dashboard preview actually look like a miniaturised dashboard?
- Numbered circles with connecting lines: is the connecting line visible? Is it correctly positioned between circles (not overlapping them)?
- The 3D tilt on the dashboard preview: is it subtle (barely perceptible) or too aggressive (distorting)? It should be the former. Dial it back if it looks wrong.
- Radial gradient halo behind the preview: is it visible but not garish? A soft purple glow, not a neon halo.

---

## Pass 2: Tour Foundation

### Sidebar Highlight
- The pulsing highlight on the active tour step sidebar item: is the pulse animation correct? It should be slow (1.5–2s period), subtle (the border brightness pulses, not the entire item), and smooth (CSS animation, not a jarring flash).
- Does the highlight correctly REMOVE from the previous item when advancing to the next step? There should never be two highlighted items simultaneously.
- At what point in the navigation cycle does the highlight update? It should update after the new page loads (400ms delay), not immediately when the user clicks Next.

### Tour Panel
- Does the gradient background look premium? Test it against the dark dashboard content behind it. If it blends in too much, increase the contrast of the gradient. If it looks out of place, reduce the gradient intensity.
- Does the panel maintain its position (`fixed, bottom: 32px, right: 32px`) correctly even when the page content scrolls?
- Does the progress bar at the top of the panel fill correctly? At Step 3 of 6, it should be exactly 50% filled.
- Font sizes within the panel: step counter should be very small (10–11px). Title should be clearly larger (17–18px). Description should be readable at 14px. Are all three visually distinct?

---

## Pass 3: Page Overlays

### Gradient Fade
This is the most technically tricky part. The gradient from transparent to solid must look natural — the page content should bleed seamlessly into the overlay content. Test this on each page:
- On Repo Insights: the chart should be partially visible above the gradient, fading into the overlay. Does it look correct?
- On Codebase Map: the treemap should peek above the gradient.
- On Settings: the settings content above should peek.

If the gradient transition looks harsh or sudden, adjust the gradient stop position. The transparent-to-solid transition should span at least 100–120px.

### Right-Column Previews
Each page overlay has a bespoke right-column preview. Review each one:

- **Optibot preview**: Do the 3 fake PR rows look like a real activity feed? Are the coloured status dots distinguishable (green/orange/red)?
- **Repo Insights preview**: Does the mini bar chart convey "analytics"? Are the bars proportional and distinct?
- **Settings preview**: Do the 3 fake toggle rows read clearly as a settings interface? Is one visibly ON (purple) and two visibly OFF (grey)?
- **Guidelines preview**: Is the split-pane layout legible at the size it's rendered? Can you distinguish the list from the editor pane?
- **Codebase Map preview**: Does the treemap preview communicate the nested rectangle concept? Are the colour variations visible?

If any preview looks like a grey blur or generic rectangle at the panel size, it needs more detail or larger representative elements.

### "Got it" Button
- Does it dismiss the overlay smoothly (slide down)?
- After dismissal, does the full page render correctly (no layout shifts)?
- Does the tour panel remain in position after overlay dismissal?

---

## Pass 4: End-to-End Flow Test

Run the complete flow from scratch:

1. Clear localStorage (`localStorage.removeItem('optimal-ai-onboarding-v1')`)
2. Navigate to `/dashboard`
3. Modal should appear: Step 1 — Connect GitHub. Verify.
4. Connect GitLab and Slack (simulate). Verify Connected states appear.
5. Click Continue → Step 2. Verify toggles. Change one setting.
6. Click Continue → Step 3. Verify two-column layout and numbered list.
7. Click "Go to dashboard" → Modal closes, tour begins.
8. Step 1 (Dashboard): Panel appears, card shimmer cascade plays. Sidebar "Dashboard" highlighted.
9. Click Next → Navigate to Optibot, page overlay slides up, sidebar "Optibot" highlighted.
10. Click "Got it" → Overlay dismisses. Explore page briefly.
11. Click Next in panel → Navigate to Repo Insights, overlay slides up.
12. Continue through Settings, Guidelines, Codebase Map.
13. Click "Finish tour" on Step 6. Toast appears. All tour UI disappears.
14. Refresh the page. Nothing appears (onboarding + tour both marked complete).
15. Clear localStorage again. Navigate to dashboard. Modal appears again from Step 1.

If any step in this flow fails or looks wrong, fix it before moving to ONBOARD_10.

---

## Pass 5: Timing & Animation Audit

All animations in the system — list them and verify each:

| Animation | Expected | Issue? |
|-----------|----------|--------|
| Modal backdrop fade in | 280ms, ease-out | |
| Modal card slide up + fade in | 280ms, ease-out | |
| Step content crossfade | 200ms opacity | |
| Progress bar fill | 300ms, ease-out | |
| Modal close (skip/complete) | 250ms fade out | |
| Tour panel entrance | 300ms, slide up | |
| Tour panel content change | 200ms crossfade | |
| Sidebar highlight entrance | 200ms | |
| Sidebar highlight pulse | 1.8s CSS animation | |
| Page overlay slide up | 400ms, ease-out | |
| Page overlay "Got it" slide down | 300ms, ease-in | |
| Dashboard card shimmer cascade | 200ms per card, sequential | |

Every animation in this list should feel smooth and intentional, not janky or abrupt.

---
*Proceed to ONBOARD_10_final_audit.md*
