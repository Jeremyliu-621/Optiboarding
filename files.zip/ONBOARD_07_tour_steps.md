# ONBOARD_07 — Tour Step Definitions

## Purpose
Define the full content for each guided tour step. This task is about copy, structure, and per-step behaviour — not building new components (those were built in ONBOARD_06).

## Tour Step Schema
Each step is defined as a data object:
```typescript
interface TourStep {
  id: number
  route: string                    // Navigate here when this step activates
  sidebarTarget: string | null     // Which nav item to highlight (matches the nav item's label or key)
  panelTitle: string
  panelDescription: string
  hasPageOverlay: boolean          // Whether this step also shows the full-page explanation overlay (see ONBOARD_08)
  nextLabel: string                // Label for the Next button
  backLabel: string
}
```

## Step Definitions

### Step 1 — Dashboard Home
```
route: '/dashboard'
sidebarTarget: 'Dashboard'
panelTitle: "Your command center"
panelDescription: "This is your dashboard home. The six cards are quick shortcuts to Optibot's core features. Below them, you'll find real-time insights and recent PR activity from your connected GitHub repos."
hasPageOverlay: false
nextLabel: "Show me Optibot →"
```

**Special behaviour for Step 1:**
In addition to the panel, highlight the "Getting Started" checklist if it's visible on the page. Apply the same pulsing border/glow to the checklist component. This mimics Image 4's approach where specific UI elements inside the page are highlighted, not just the sidebar.

Also: briefly highlight (1.5s, then return to normal) the six feature cards by applying a gentle shimmer/glow animation to them in sequence — one after another, like a cascade. This draws the eye downward through the page. The shimmer should be subtle: a thin bright border that appears and fades on each card in sequence, left-to-right, top-to-bottom.

### Step 2 — Optibot
```
route: '/dashboard/optibot'
sidebarTarget: 'Optibot'
panelTitle: "Meet Optibot"
panelDescription: "Optibot is your AI code reviewer. It reads your entire codebase before reviewing each PR — not just the diff. Use this page to trigger manual reviews, configure its behaviour, and see what it's reviewed recently."
hasPageOverlay: true
nextLabel: "Explore Repo Insights →"
```

**Special behaviour for Step 2:**
When this step activates:
1. Navigate to `/dashboard/optibot`
2. After 400ms (page has loaded): show the page overlay (ONBOARD_08 handles this)
3. The sidebar "Optibot" item is highlighted

### Step 3 — Repo Insights
```
route: '/dashboard/insights'
sidebarTarget: 'Repo Insights'
panelTitle: "Understand your codebase"
panelDescription: "Repo Insights shows how Optibot is affecting your team's velocity. Track merge time trends, review frequency, and security issue detection. Use the repository and time range selectors to drill into specific repos or periods."
hasPageOverlay: true
nextLabel: "Go to Settings →"
```

### Step 4 — Settings
```
route: '/dashboard/configuration'
sidebarTarget: 'Settings'
panelTitle: "Fine-tune Optibot"
panelDescription: "Settings is where you control how Optibot behaves across your workspace. The review settings you configured during onboarding live here — you can change them any time. You'll also find your API key and webhook configuration."
hasPageOverlay: true
nextLabel: "See Guidelines →"
```

**Special behaviour for Step 4:**
Automatically switch to the Settings tab when navigating here (not the Guidelines tab). The settings page is tabbed — make sure the correct tab is active.

### Step 5 — Guidelines
```
route: '/dashboard/configuration?tab=guidelines'
sidebarTarget: 'Guidelines'
panelTitle: "Teach Optibot your rules"
panelDescription: "Guidelines are natural-language instructions for Optibot. Tell it what your team cares about — security patterns to flag, style rules to enforce, or files to ignore. Optibot reads these before every review."
hasPageOverlay: true
nextLabel: "View Codebase Map →"
```

**Special behaviour for Step 5:**
The sidebar still highlights "Guidelines" (or the Configuration section if Guidelines is nested). Navigate to the guidelines tab specifically — use a URL query param (`?tab=guidelines`) and make sure the configuration page reads this param to activate the correct tab.

### Step 6 — Codebase Map
```
route: '/dashboard/codebase-map'
sidebarTarget: 'Codebase Map'
panelTitle: "See your whole codebase"
panelDescription: "The Codebase Map shows your repository as an interactive treemap. Each rectangle is a file — sized by lines of code, coloured by Optibot's review coverage or issue density. Click any directory to zoom in."
hasPageOverlay: true
nextLabel: "Finish tour"
```

**Special behaviour for Step 6:**
This is the last step. "Next" becomes "Finish tour". When clicked:
- Mark `tourCompleted: true` in localStorage
- Show a brief completion toast: "You're all set! Optibot is ready to review your code." — using whatever toast system exists in the project, or create a simple one
- Remove all tour UI (panel, sidebar highlights)

## Step Data File
Create `src/lib/tourSteps.ts` exporting the array of `TourStep` objects matching the definitions above. Import this in `TourProvider`. This keeps step definitions out of the component code and makes them easy to edit.

## Transition Behaviour Between Steps
When advancing from Step N to Step N+1:
1. If the route changes: the panel content updates immediately (the route navigating happens in the background)
2. Wait 400ms after navigation for the new page to render
3. If `hasPageOverlay: true`, show the page overlay (see ONBOARD_08)
4. The sidebar highlight transitions: old item de-highlights (200ms), new item highlights (200ms, after 100ms delay)

Between steps on the same route (none currently, but plan for it): just crossfade the panel content.

## Back Button Behaviour
Going Back from Step 2 (Optibot) to Step 1 (Dashboard):
- Navigate back to `/dashboard`
- Show the page without the page overlay (Step 1 has no page overlay)
- Panel content reverts to Step 1

Going Back always navigates to the previous route and previous sidebar highlight. Mirror the Forward behaviour in reverse.

## Self-Evaluation Before Moving On
- [ ] Is `tourSteps.ts` correctly typed and exported?
- [ ] Does navigating forward through all 6 steps work without errors?
- [ ] Does navigating backward work correctly?
- [ ] Does Step 1's card shimmer cascade animation run on entry?
- [ ] Does Step 6's "Finish tour" show the toast and clean up all tour UI?
- [ ] Do the sidebar highlights correctly change at each step?

---
*Proceed to ONBOARD_08_tour_page_overlays.md*
