# ONBOARD_08 — Per-Page Gradient Explanation Overlays

## Purpose
Build the full-page explanation overlays that appear when the tour navigates to a new page. These are distinct from the floating panel (which persists throughout the tour) — these are temporary, page-level "here's what you're looking at" moments that the user dismisses to reveal the actual page.

## Reference: Image 4 (Stripe) + Image 5
- Image 4: When Stripe lands on the home page after onboarding, a gradient overlay covers the lower portion of the page with a large headline ("Next, verify your business"), body text, a CTA button, and a separate setup guide panel in the corner. The real page content is visible behind/above the overlay.
- Image 5: The clean toggle-panel aesthetic — used for the sidebar settings section. Adopt this as the style reference for the inline explanatory content within the overlay.

## What This Overlay Is NOT
- NOT a modal (no backdrop dimming, the page is still fully visible)
- NOT a tooltip pointing at elements
- NOT blocking — it appears over the page's main content area but the sidebar and header are still fully usable

## What This Overlay IS
A full-width panel that slides up from the bottom of the main content area when a tour step activates on a new page. It covers roughly the bottom 45–55% of the main content area (not the sidebar, not the header). The real page content is visible in the top portion.

Think of it as a "drawer" that slides up from the bottom of the content area — behind the floating tour panel (which is always on top).

## Visual Design

### Overlay Panel
- `position: fixed`
- Spans from `left: 220px` (sidebar width) to `right: 0`, covering only the main content area
- From `bottom: 0` up to approximately 50% of the viewport height
- Background: a gradient that transitions from fully transparent at the top edge to `hsl(275, 15%, 7%)` (the deep background colour) about 80px below the top edge, then solid `hsl(275, 15%, 7%)` for the rest. This creates a natural fade-in from the page content above.
- The gradient transition: `background: linear-gradient(to bottom, transparent 0%, hsl(275, 15%, 7%) 80px, hsl(275, 15%, 7%) 100%)`

This means the page content bleeds naturally through the top of the overlay, which then solidifies into the explanatory content. Exactly like Stripe's Image 4 — the page chart is visible above the "Next, verify your business" overlay.

### Animation
- Entrance: slide up from `translateY(100%)` to `translateY(0)`, 400ms ease-out
- Exit: slide down `translateY(100%)`, 300ms ease-in
- This happens BEFORE the floating panel changes content (overlay slides up, user reads, user clicks Next → overlay slides down, new route loads, new overlay slides up)

### Overlay Content Layout
The content inside the overlay (in the solid portion, below the transparent gradient) is arranged in a two-column layout:

**Left column (~55%):**
- A large, bold page title (distinct from the floating panel title — more dramatic, larger)
- A 2–3 sentence explanation of the page
- Below that: 2–3 bullet feature highlights (use a dash or small dot, NOT Lucide icons — keep it typographic)
- A "Got it" or "Continue" button — outlined style, using `--accent` border and text, medium size. Clicking this dismisses the overlay and shows the full page, but does NOT advance the tour step — the floating panel still shows and the user can explore before pressing Next in the panel.

**Right column (~45%):**
A simplified component-level preview of the page's most distinctive UI. This is CSS-only, not real components. Each page gets a bespoke preview:

**Optibot page overlay — right column:**
Show a simplified version of the recent reviews feed: 3 fake PR rows, each with a left-coloured dot (green, orange, red), a fake PR title in white, a "Reviewed" label, and a timestamp. Monospace-ish font. Very compact. Represents what the Optibot feed looks like.

**Repo Insights overlay — right column:**
Show a simplified mini chart: 4–5 bars of varying heights in muted accent colour, with a baseline, a tiny "Merge Time (days)" label. Below it, 3 small stat numbers in a row: "142 PRs", "3 Issues", "~48h saved". Clean, data-dense.

**Settings overlay — right column:**
Replicate a 3-row version of the toggle UI from Image 5, but as static CSS (no actual toggles — just visual representations). One row ON (purple toggle), two rows OFF (grey). Label and description text. This immediately communicates "this page has toggle settings."

**Guidelines overlay — right column:**
Show a simplified version of the split-pane editor: left side, 3 small labelled rows in a list (representing guidelines). Right side, a textarea-shaped rectangle with a few lines of fake monospace text. Communicates the editor pattern.

**Codebase Map overlay — right column:**
Show a simplified treemap: 4–6 rectangles of different sizes arranged in a nested grid, in varying shades of the accent colour (lighter = more coverage, darker = less). A small legend below with two coloured squares and labels "High coverage" / "Needs review". Immediately communicates the visual.

## Per-Page Overlay Content

### Optibot Page
```
Large title: "Optibot — your AI reviewer"
Description: "Optibot reads your entire codebase, not just the diff. It understands context that file-level tools miss — like whether this PR breaks an invariant defined three files away, or introduces a security pattern your guidelines explicitly flag."
Bullets:
- Runs automatically on every opened PR
- Posts structured review comments directly to GitHub
- Trigger manual reviews on any PR URL
```

### Repo Insights Page
```
Large title: "See the impact"
Description: "Repo Insights tracks how Optibot is changing your team's velocity. The most important metric: time from PR open to merge. Teams using Optibot see this drop within the first two weeks."
Bullets:
- Filter by repository and time range
- Sortable PR activity table with Optibot verdicts
- Security issue breakdown by category
```

### Settings Page
```
Large title: "Optibot does what you tell it"
Description: "The settings you configured during onboarding live here. Review thoroughness, trigger behaviour, focus areas — everything that determines how Optibot approaches each PR. Change them any time and Optibot adapts immediately."
Bullets:
- Toggle auto-review triggers independently
- Configure minimum PR size thresholds
- API keys and webhook URLs for CI/CD integration
```

### Guidelines Page
```
Large title: "Your rules, enforced"
Description: "Guidelines are plain-English instructions Optibot reads before every review. They're more flexible than linters — you can describe patterns, architectural decisions, or team conventions in natural language."
Bullets:
- Toggle guidelines on/off without deleting them
- Set priority: low, medium, or high severity
- Preview how Optibot interprets each guideline
```

### Codebase Map Page
```
Large title: "Your entire codebase, at a glance"
Description: "The Codebase Map shows coverage and issue density across your repository. Click any directory to zoom in. Use it to find files Optibot hasn't reviewed yet, or to see where issues are clustering."
Bullets:
- Click directories to zoom in, breadcrumb to navigate back
- Colour by coverage, issue density, or file size
- Switch to list view for a sortable data table
```

## "Got it" Dismiss Behaviour
When the user clicks "Got it" on an overlay:
- The overlay slides down (exits)
- The full page is now visible and explorable
- The floating tour panel (ONBOARD_06) remains in the bottom-right corner, showing the current step
- The user can explore the page freely before pressing Next in the panel
- This is the same pattern as Stripe's "Got it" button in Image 4

## Self-Evaluation Before Moving On
- [ ] Does the overlay correctly cover only the main content area (not sidebar or header)?
- [ ] Does the gradient fade work — is the page content visible through the top of the overlay?
- [ ] Does the slide-up animation feel smooth and substantial?
- [ ] Is each page's right-column preview recognisably different and page-specific?
- [ ] Does "Got it" dismiss the overlay without advancing the tour step?
- [ ] Do the overlay and floating panel coexist without z-index conflicts?
- [ ] Does the overlay NOT appear on Step 1 (Dashboard Home)?

---
*Proceed to ONBOARD_09_polish_iteration.md*
