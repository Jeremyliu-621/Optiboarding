# ONBOARD_01 — Modal Foundation: Shell, Overlay, Navigation

## Purpose
Build the reusable modal shell that all three onboarding steps will live inside. This is the most important component to get right — everything else is content inside this shell.

## Visual Reference: Stripe's Modal (Images 1, 2, 3)
Study all three Stripe screenshots carefully. The shell is identical across all three steps. Extract these exact properties:
- The backdrop: the entire viewport behind the modal is dimmed with a semi-transparent overlay. The Stripe dashboard is still visible but muted behind it.
- The modal itself: large white rounded rectangle. Estimate it at roughly 900–1000px wide and 600–700px tall. It is NOT full-screen — it floats centered in the viewport with visible dimmed background on all sides.
- Top-left: the Stripe wordmark logo. For Optimal AI, use the existing logo/wordmark from the sidebar — find how it's currently rendered and replicate it inside the modal.
- Top-right: a thin horizontal progress bar. In Stripe it's a short bar that grows across steps. Position it at the very top-right corner of the modal interior. It is NOT a labeled "Step 1 of 3" — just a visual bar.
- Bottom bar: a thin separator line across the full modal width, then a footer row below it. Left side: "← Back" link (hidden on Step 1). Right side: "Skip for now" text link + filled primary CTA button. Both text links are understated — not buttons. The CTA button is filled, rounded, uses the brand primary colour.
- Content area: generous vertical and horizontal padding. Content starts well below the top bar and well above the bottom bar. Lots of breathing room.

## Component Architecture

Create `src/components/onboarding/OnboardingModal.tsx` — this is the shell.

It accepts:
- `isOpen: boolean`
- `onClose: () => void`
- `currentStep: number` (1, 2, or 3)
- `totalSteps: number` (3)
- `onNext: () => void`
- `onBack: () => void`
- `onSkip: () => void`
- `nextLabel: string` (e.g. "Continue", "Go to dashboard")
- `backVisible: boolean`
- `skipVisible: boolean`
- `children: React.ReactNode` — the step content

It renders:
1. A full-viewport fixed overlay (`position: fixed, inset: 0`) with `background: rgba(0,0,0,0.5)`. Use Framer Motion `AnimatePresence` + `motion.div` to fade this in/out.
2. Inside the overlay, centered: the modal card. White background (`#ffffff`), border-radius `12px`, box-shadow substantial (this floats above everything). Width: `min(960px, 90vw)`. Height: `auto` with a `min-height: 580px`. Do NOT use the design system dark colours here — this modal is intentionally white/light, like Stripe's.
3. Inside the modal card:
   - Top bar: flex row, `padding: 28px 36px 0`. Logo left, progress bar right.
   - Progress bar: a thin bar, about 160px wide, height 3px, grey background, filled portion in brand primary colour. The filled width is `(currentStep / totalSteps) * 100%`. Animate the width change with a CSS transition.
   - Content area: `padding: 48px 80px 32px`. This is where `children` render.
   - Bottom bar: a 1px line in light grey, then a footer row with `padding: 20px 36px`. Back link left, Skip + CTA right.

## Animation
- Modal entrance: fade in overlay + slide modal up slightly (translateY from 16px to 0, opacity 0 to 1). Duration 280ms, easing ease-out.
- Step transitions: when currentStep changes, the content area should crossfade — old content fades out, new content fades in. Do NOT slide horizontally (too busy). Simple opacity transition, 200ms.
- Do NOT animate the progress bar on initial render — only animate it when advancing between steps.

## Typography Inside Modal
The modal is white, so text colours are standard light-background colours:
- Headings: `#0a0a0a`, font-weight 700, use Inter or the heading font from the design system
- Body: `#4a4a4a`
- Muted: `#8a8a8a`
- Labels: `#1a1a1a`, font-weight 500
- Input borders: `#d4d4d4`
- Input focus border: brand primary colour

## Logo in Modal
Find how the Optimal AI wordmark/logo is rendered in the sidebar. Extract just the wordmark (text + icon mark) and render it in the top-left of the modal at approximately sidebar-logo size. It should be the coloured version (not inverted for dark bg).

## Bottom Bar Behaviour
- Step 1: Back hidden, Skip visible, CTA = "Continue"
- Step 2: Back visible, Skip visible, CTA = "Continue"  
- Step 3: Back visible, Skip hidden, CTA = "Go to dashboard"

The "Skip for now" should call `onSkip`. The back link should call `onBack`. The CTA calls `onNext`.

## Self-Evaluation Before Moving On
- [ ] Does the modal look visually close to Stripe's modal shell in Images 1–3?
- [ ] Is the backdrop visible and correctly dimming content behind it?
- [ ] Does the progress bar animate smoothly between steps?
- [ ] Does the step content transition work (crossfade, no jump)?
- [ ] Is the white modal clearly floating above the dark dashboard behind it?
- [ ] Do the back/skip/CTA buttons behave correctly per step?
- [ ] Does the modal close correctly when skip or final CTA is clicked?

---
*Proceed to ONBOARD_02_step_github.md*
