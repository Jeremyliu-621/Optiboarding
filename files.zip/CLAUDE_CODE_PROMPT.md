You are implementing a complete onboarding and guided tour system for the Optimal AI dashboard. This is an overnight build job — take your time, do it right, and iterate until it's genuinely good.

Read the task folder README first. Then execute ONBOARD_00 through ONBOARD_10 in strict order. Do not skip a task. Do not skip the self-evaluation checklist at the end of each task — if something fails the checklist, fix it before moving on.

The two systems you are building:

1. A STRIPE-QUALITY first-login onboarding modal. Three steps. Large white modal floating over the dimmed dark dashboard. Logo top-left, progress bar top-right, back/skip/CTA in a bottom bar. The modal is white — intentionally different from the dark design system. Study the reference images described in each task file before building.

2. A CONTEXTUAL GUIDED TOUR that starts after onboarding. A fixed floating panel (bottom-right, gradient dark background) walks the user through the dashboard. Each page gets a full-page explanation overlay that slides up from the bottom, showing a gradient fade and page-specific content previews. The sidebar highlights the active tour step.

Non-negotiable rules:
- White modal = intentional, not a bug. Do not apply dark design system colours inside the modal.
- All state via localStorage key `optimal-ai-onboarding-v1`. Schema defined in ONBOARD_05.
- No window.alert(), no window.confirm(), no placeholder onClick handlers, no console.log.
- TypeScript throughout. No `any`.
- Every animation must feel smooth — see the animation timing table in ONBOARD_09.
- The end-to-end flow test in ONBOARD_09 must pass completely before marking done.

Start by reading ONBOARD_00 and exploring the existing codebase. Understand what's already there before writing anything. The existing onboarding checklist ("Getting Started 0/3") may be replaced or repurposed — understand it first.
