# ONBOARD_03 — Step 2: Configure Default Review Settings

## Purpose
Build the content for onboarding Step 2. The user configures how Optibot will behave by default. This gives them agency and makes the product feel immediately personalised.

## Visual Reference: Image 5
Image 5 shows the settings panel inside the existing dashboard — a list of toggle rows. Study the toggle component carefully: it's a rounded pill toggle, purple when active, grey when inactive. The row has a bold label, a muted description below it, and the toggle right-aligned. This same pattern is used here, but inside the white modal context.

Also reference Stripe Step 2 (Image 2): option cards with radio buttons. The Optibot settings are NOT radio buttons — they're independent toggles. But the card-per-option visual treatment from Stripe (rounded rectangle per option, with a border/background) is useful inspiration for grouping.

## Content Layout

### Headline
```
How should Optibot review your code?
You can fine-tune these in Settings at any time.
```
First line: bold, dark. Second line: muted body text.

### Settings Sections
Group the toggles into two visual groups with a subtle section divider between them. Use a light-coloured section container for each group — `#f7f7f7` background, `border-radius: 10px`, `padding: 4px 0`. Each toggle row inside has `padding: 14px 20px`, and rows are separated by a 1px `#ebebeb` divider line.

**Group 1: Trigger Behaviour**
Mirrors what's in Image 5. These are the same settings — the user is configuring them during onboarding:

1. **Auto review** — Default ON
   "Automatically review every PR when it's opened."

2. **Auto review on draft** — Default OFF
   "Include draft PRs in automatic reviews."

3. **Auto review on push** — Default OFF
   "Trigger a new review whenever commits are pushed to an open PR."

4. **Auto review after workflow** — Default OFF
   "Only trigger a review after CI passes."

**Group 2: Review Style**

5. **Allow approve** — Default OFF
   "Optibot can approve PRs that pass all checks without human sign-off."

6. **Code suggestions** — Default ON
   "Generate inline code suggestions alongside review comments."

### Toggle Component
In the white modal context, the toggle appearance needs to be correct:
- Active: pill background in brand primary colour (purple), white circle thumb
- Inactive: pill background `#d4d4d4`, white circle thumb
- Transition: smooth CSS transition on the thumb position and background colour

If the existing dark-theme toggle component from the dashboard settings page exists, do NOT reuse it directly — its colours may be hardcoded for dark backgrounds. Create a `ToggleWhite` variant or a context-aware toggle that accepts a `theme: 'light' | 'dark'` prop, then use `'light'` here.

### State
Each toggle is independent state. Expose all toggle values via a prop callback `onSettingsChange(settings: ReviewSettings)` where `ReviewSettings` is a typed object with all 6 boolean fields. The parent collects this for persistence.

Default values match what's described above (ON = auto review, code suggestions; everything else OFF).

## Visual Weight Balance
Six toggle rows is a lot. Make sure the modal doesn't feel like a form dump. The key is:
- Generous row height (not cramped)
- Clear visual grouping (the two section boxes)
- The section labels above each group should be uppercase, small, muted — like `TRIGGER BEHAVIOUR` and `REVIEW STYLE`
- The description text under each label is essential — don't remove it to save space

## Self-Evaluation Before Moving On
- [ ] Do the toggles work independently?
- [ ] Are default states correct (auto review ON, code suggestions ON, rest OFF)?
- [ ] Are the two sections visually distinct from each other?
- [ ] Do toggle colours render correctly on the white background (not using dark-theme vars)?
- [ ] Does the settings state get correctly passed up to the parent via callback?
- [ ] Does the step feel like a real configuration experience, not a form?

---
*Proceed to ONBOARD_04_step_sandbox.md*
