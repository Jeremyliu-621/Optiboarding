# ONBOARD_10 — Final Audit

## Purpose
This is the last gate before the work is considered complete. No feature additions — only verification, fixes, and cleanup.

---

## 1. Functional Completeness Matrix

Verify every item in this matrix works correctly:

### Onboarding Modal
| Feature | Works? | Notes |
|---------|--------|-------|
| Modal appears on first visit to /dashboard | | |
| Modal does NOT appear after completion | | |
| Modal does NOT appear after being skipped (within 7 days) | | |
| Modal reappears after 7+ days if previously skipped | | |
| Step 1: GitHub Connected chip shows real @username | | |
| Step 1: Optional integration simulate-connect works | | |
| Step 1: Connected state persists when navigating Back from Step 2 | | |
| Step 2: All 6 toggles work independently | | |
| Step 2: Default states are correct | | |
| Step 2: Toggle states persist when navigating Back from Step 3 | | |
| Step 3: Two-column layout renders at 1280px+ | | |
| Step 3: Numbered list with connecting lines renders correctly | | |
| Step 3: Dashboard preview panel is recognisable | | |
| Progress bar: correct fill at each step | | |
| Back button: hidden on Step 1, visible on Steps 2+3 | | |
| Skip button: visible on Steps 1+2, hidden on Step 3 | | |
| CTA label: "Continue" on Steps 1+2, "Go to dashboard" on Step 3 | | |
| Backdrop: correctly dims dashboard content | | |
| Modal close animation plays on completion and skip | | |

### localStorage Integration
| Feature | Works? |
|---------|--------|
| Review settings from Step 2 reflected in /dashboard/configuration Settings tab | |
| Connected integrations from Step 1 reflected in /dashboard/integrations | |
| tourCompleted=false triggers tour after modal closes | |
| tourCompleted=true skips tour on next visit | |

### Guided Tour
| Feature | Works? | Notes |
|---------|--------|-------|
| Tour starts automatically after onboarding completes | | |
| Step 1: Dashboard — panel visible, card shimmer plays | | |
| Step 2: Navigate to /dashboard/optibot, sidebar highlighted | | |
| Step 3: Navigate to /dashboard/insights, sidebar highlighted | | |
| Step 4: Navigate to /dashboard/configuration, Settings tab active | | |
| Step 5: Navigate to /dashboard/configuration, Guidelines tab active | | |
| Step 6: Navigate to /dashboard/codebase-map, sidebar highlighted | | |
| Tour panel: correct step counter at each step | | |
| Tour panel: progress bar correct at each step | | |
| Tour panel: Back navigation works | | |
| Skip tour: clears all tour UI | | |
| Finish tour: toast appears, all UI clears | | |
| Sidebar highlights: only one active at a time | | |
| Sidebar highlights: correctly removed after tour ends | | |

### Page Overlays
| Feature | Works? |
|---------|--------|
| Optibot overlay: slides up, gradient fade correct | |
| Optibot overlay: right column preview looks like a feed | |
| Repo Insights overlay: chart preview visible | |
| Settings overlay: toggle rows visible | |
| Guidelines overlay: split-pane layout visible | |
| Codebase Map overlay: treemap preview visible | |
| "Got it" on each overlay: correctly dismisses | |
| After "Got it": page is fully usable, tour panel remains | |
| No overlay appears on Step 1 (Dashboard Home) | |

---

## 2. Code Quality Checklist
- [ ] No `any` TypeScript types
- [ ] No `console.log` statements remaining
- [ ] No placeholder `onClick={() => {}}` handlers
- [ ] No `window.alert()` or `window.confirm()` calls
- [ ] All components have correct display names (for React DevTools)
- [ ] `OnboardingState` interface is exported from a shared types file and imported everywhere it's used (not re-defined)
- [ ] `tourSteps.ts` data file is clean and matches step definitions from ONBOARD_07
- [ ] No hardcoded pixel values that should reference CSS variables

---

## 3. Visual Consistency Check

Open every page the tour visits and check:
- Does the tour panel look correct on each page? (no z-index issues with page content)
- Does the sidebar highlight not cause layout shifts in the sidebar?
- Does the page overlay correctly stop at the sidebar edge on all pages?
- Do the overlay right-column previews look polished and intentional (not like developer placeholders)?

---

## 4. Regression Check

Verify the onboarding/tour system did not break anything that was working before:
- [ ] Dashboard home page renders correctly with tour completed
- [ ] All 6 dashboard feature cards navigate correctly
- [ ] Sidebar navigation works normally after tour is completed
- [ ] Settings page toggles work independently of onboarding state
- [ ] Integrations page works independently of onboarding state
- [ ] Auth flow (login/logout) is not affected

---

## 5. Final Cleanup
- Remove any `TODO` or `FIXME` comments
- Remove any test/debug code (e.g. `localStorage.clear()` calls left in component code)
- Ensure no onboarding components are imported but unused
- Verify the `OnboardingProvider` is mounted in exactly one place

---

## Done
When this audit is complete with every item verified, the onboarding and guided tour system is finished. The product should feel like it has a first-class, Stripe-quality onboarding experience.
