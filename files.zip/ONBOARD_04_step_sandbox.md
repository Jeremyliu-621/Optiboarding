# ONBOARD_04 — Step 3: "You're Ready" Summary Screen

## Purpose
Build the content for onboarding Step 3. This is the closing step — the user has connected their tools and configured their settings. Now give them confidence that they're set up correctly and show them what comes next. This is directly modelled on Stripe's Step 3 (Image 3).

## Visual Reference: Stripe Step 3 (Image 3) — Replicate This Layout Closely
Study Image 3 in detail. The layout is:
- **Left column (~55% width)**: text content — a headline, then a numbered vertical list of steps with connecting lines between them
- **Right column (~45% width)**: a UI preview mockup — a dark/styled panel showing a preview of the product

This two-column layout is distinctive and makes the final step feel like a reveal/graduation moment rather than just another form. Replicate this structure for Optimal AI.

## Left Column Content

### Headline
```
You're all set.
Start reviewing code with full codebase context.
```
"You're all set." — bold, dark. Second line — muted, normal weight.

### Numbered Step List
Three numbered items with a vertical line connecting the circles (like Stripe's numbered list in Image 3). The circles are filled with brand primary colour, white number inside.

The connecting line between circles is a thin vertical line in a lighter tint of the primary colour, running from the bottom of circle 1 to the top of circle 2, etc.

Each item has:
- A numbered circle (28px diameter)
- A bold step title to the right of the circle
- A muted description below the title

The three items:
1. **Review your first PR**
   "Open a pull request and Optibot will automatically post a review within minutes."

2. **Explore your codebase**
   "Use the Codebase Map to see which files are covered and where issues are concentrated."

3. **Invite your team**
   "Add teammates from the Organization page to share Optibot across your workspace."

Spacing: generous gap between each numbered item.

## Right Column Content: Dashboard Preview Mockup
This is a stylised preview panel — NOT a screenshot, but a hand-crafted CSS/SVG mockup of the Optimal AI dashboard. It should feel like a simplified, miniaturised version of the dashboard as seen in Image 6.

The panel:
- Dark background matching `--bg-deep` from the design system (`hsl(275, 15%, 7%)`)
- `border-radius: 12px`
- Positioned slightly offset/tilted — in Stripe's Image 3, the right panel has a subtle rotational tilt and is not perfectly straight. Apply a `transform: perspective(800px) rotateX(2deg) rotateY(-4deg)` or similar very subtle 3D tilt to give it depth.
- Inside the panel, render a simplified mockup of the dashboard — this is CSS-only, not real components. Build it as an SVG or a set of styled divs that represent:
  - A thin dark sidebar strip on the left with small icon dots
  - A header bar with a fake search box rectangle
  - A 2x3 grid of small rounded rectangles representing the feature cards (the cards from Image 6)
  - Below the grid, a small horizontal stat row
  - The Optimal AI wordmark/logo in the top-left corner of the panel (very small, white)

The mockup does NOT need to be pixel-accurate. It needs to be recognisably "a dashboard" and use the correct dark colours. Avoid adding real text that would require tiny font sizes — use placeholder bars and shapes.

Add a subtle gradient background BEHIND the right column panel (not on the panel itself) — a soft radial gradient in the brand purple, very muted, that bleeds out from behind the panel. This matches the subtle halo effect in Stripe's Image 3.

## Layout
The two columns sit side-by-side, vertically centred relative to each other. The modal content area at this step has slightly more vertical padding than Steps 1–2 to make the layout feel airier.

The "Go to dashboard" CTA in the footer (this is the final step, so no "Skip for now" — just Back and the CTA).

When the user clicks "Go to dashboard":
1. The modal closes (fade out)
2. After 300ms: the guided tour begins (this is handled by the state system in ONBOARD_05)

## Self-Evaluation Before Moving On
- [ ] Does the two-column layout match the general structure of Stripe's Step 3?
- [ ] Are the numbered circles with connecting lines rendered correctly?
- [ ] Does the dashboard mockup panel look like a miniaturised dashboard (not a grey box)?
- [ ] Does the subtle tilt/3D effect on the panel add depth without being distracting?
- [ ] Does the radial gradient halo behind the right panel look like Stripe's?
- [ ] Is "Skip for now" hidden on this step and "Back" visible?
- [ ] Does clicking "Go to dashboard" close the modal cleanly?

---
*Proceed to ONBOARD_05_integration.md*
