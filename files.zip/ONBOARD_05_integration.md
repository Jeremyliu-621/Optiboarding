# ONBOARD_05 — Integration: Auth Flow, State Persistence, First-Login Detection

## Purpose
Wire everything together. The modal must appear automatically on first login, never appear again on subsequent logins, and persist the user's choices (integrations connected, settings configured) to influence the rest of the dashboard.

## First-Login Detection

### Strategy
Use localStorage as the persistence layer. The key is `optimal-ai-onboarding-v1`. The value is a JSON object (schema below). On every dashboard load, check this key:
- If the key doesn't exist: show the onboarding modal
- If the key exists and `completed: true`: skip onboarding, optionally start the tour if `tourCompleted: false`
- If the key exists and `completed: false`: resume from the last completed step

### localStorage Schema
```typescript
interface OnboardingState {
  completed: boolean           // Whether onboarding modal was finished (not skipped)
  skipped: boolean             // Whether the user hit "Skip for now" at any point
  completedAt: string | null   // ISO timestamp
  currentStep: number          // 1, 2, or 3 — last step reached
  connectedIntegrations: {
    github: boolean
    gitlab: boolean
    slack: boolean
    jira: boolean
  }
  reviewSettings: {
    autoReview: boolean
    autoReviewOnDraft: boolean
    autoReviewOnPush: boolean
    autoReviewAfterWorkflow: boolean
    allowApprove: boolean
    codeSuggestions: boolean
  }
  tourCompleted: boolean        // Whether the post-onboarding tour was finished
  tourCurrentStep: number       // Which tour step the user is on (0 = not started)
}
```

The defaults (when the key doesn't exist, i.e. new user):
```typescript
{
  completed: false,
  skipped: false,
  completedAt: null,
  currentStep: 1,
  connectedIntegrations: { github: true, gitlab: false, slack: false, jira: false },
  reviewSettings: { autoReview: true, autoReviewOnDraft: false, autoReviewOnPush: false, autoReviewAfterWorkflow: false, allowApprove: false, codeSuggestions: true },
  tourCompleted: false,
  tourCurrentStep: 0
}
```

Note: `github: true` in defaults because the user just OAuth'd with GitHub to reach the dashboard.

### Where to Mount the Onboarding Modal
Find where to mount the `<OnboardingModal>` in the component tree. The ideal place is in `src/app/dashboard/layout.tsx` since all dashboard routes share this layout. This way the modal appears regardless of which dashboard URL the user lands on after OAuth.

Alternatively, if the layout has client/server component complications (Next.js 15 can be tricky here), find the correct client component boundary. The onboarding logic MUST be in a client component since it uses localStorage and React state.

Create a `src/components/onboarding/OnboardingProvider.tsx` — a client component that:
- Reads localStorage on mount
- Determines if onboarding should show
- Renders `<OnboardingModal>` with the correct initial state
- Updates localStorage whenever state changes

Mount `<OnboardingProvider>` inside the dashboard layout, wrapping the page content but inside the sidebar/header structure (so the modal overlays the full dashboard, not just the main content area).

### Session Timing
There's a timing risk: the session might not be available immediately when the component mounts. Handle this:
- Show nothing (no modal) until the session is confirmed
- Once `session.user` is available, THEN check localStorage and potentially show the modal
- This prevents a flash of the modal before the session resolves

## Applying the User's Choices

### Review Settings
When onboarding is completed, the `reviewSettings` from Step 2 should be reflected in the Settings page. The Settings page (`/dashboard/configuration` → Settings tab) should read from the same localStorage key and pre-populate its toggle states from `onboardingState.reviewSettings`. If the onboarding was skipped, use the defaults.

### Connected Integrations
The Integrations page (`/dashboard/integrations`) should read `onboardingState.connectedIntegrations` and pre-populate the connection status for each service. If a user "connected" Slack during onboarding, the Slack tab should show "Connected" status.

### GitHub Username
The session provides the GitHub username. Store it in a separate localStorage key `optimal-ai-user-v1` for use across the dashboard.

## Skip Behaviour
If the user clicks "Skip for now" at any point:
- Set `skipped: true`, `completed: false` in localStorage
- Close the modal
- Do NOT start the guided tour
- On next login, the modal shows again from step 1 (skip is not permanent)

Actually, reconsider: if the user skipped, showing the modal again on every login is annoying. Better approach: if skipped, set `skipped: true` AND store a `skippedAt` timestamp. Only show the modal again if `skippedAt` was more than 7 days ago. After 7 days, reset `skipped: false`. This is more respectful of the user's time.

## Tour Trigger
When onboarding is completed (CTA on Step 3 clicked):
- Set `completed: true`, `completedAt: now`, `tourCurrentStep: 1`
- Close the modal
- After a 600ms delay (let the modal close animate), start the guided tour

This delay + tour start is handled by the `OnboardingProvider` via a state machine: `'idle' | 'onboarding' | 'tour' | 'done'`.

## Self-Evaluation Before Moving On
- [ ] Does the modal appear on first visit to the dashboard?
- [ ] Does the modal NOT appear on page refresh after completion?
- [ ] Does localStorage correctly store all the user's choices?
- [ ] Does the Settings page reflect the review settings from onboarding?
- [ ] Does the Integrations page reflect the connected integrations from onboarding?
- [ ] Does the tour start automatically after onboarding completes?
- [ ] Does the skip-and-resurface-after-7-days logic work correctly?

---
*Proceed to ONBOARD_06_tour_foundation.md*
